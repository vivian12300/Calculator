import Cocoa

var greeting = "Hello, playground"

//input variables
var number1 = 5
var number2 = 9
var number3 = 10
var number4 = 7
var number5 = 13
var number6 = 4

//operators
let Op1 = number6 + number5
let Op2 = number2 + number1
let Op3 = number3 + number4
let Op4 = number4 / number3
let Op5 = number1 / number2
let Op6 = number5 / number6
let Op7 = number2 * number1
let Op8 = number5 * number6
let Op9 = number3 * number4
let Op10 = number2 - number1
let Op11 = number4 - number3
let Op12 = number5 - number6

//print
print(Op1)
print(Op2)
print(Op3)
print(Op4)
print(Op5)
print(Op6)
print(Op7)
print(Op8)
print(Op9)
print(Op10)
print(Op11)
print(Op12)
